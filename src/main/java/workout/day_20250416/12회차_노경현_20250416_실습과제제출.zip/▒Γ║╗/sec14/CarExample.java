package workout.day_20250416.기본.sec14;

public class CarExample {

  public static void main(String[] args) {
    Car myCar = new Car();

    myCar.setSpeed(-50);
    myCar.print();

    myCar.setSpeed(60);
    myCar.print();

    myCar.setStop(true);
    myCar.print();

  }

}
