package workout.day_20250416.기본.sec11.exam02;

public class Earth {
  static int half = 64000;
  static double surface;
  static {
    surface = 4 * 3.141592 * half * half;
  }
}
