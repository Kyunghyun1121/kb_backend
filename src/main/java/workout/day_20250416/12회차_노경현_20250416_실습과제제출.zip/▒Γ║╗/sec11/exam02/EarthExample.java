package workout.day_20250416.기본.sec11.exam02;

public class EarthExample {

  public static void main(String[] args) {
    Earth earth = new Earth();
    System.out.println(earth.half);
    System.out.println(earth.surface);
  }

}
