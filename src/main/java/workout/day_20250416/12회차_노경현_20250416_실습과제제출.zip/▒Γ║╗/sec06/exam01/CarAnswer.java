package workout.day_20250416.기본.sec06.exam01;

public class CarAnswer {
  String model;
  boolean start;
  int speed;
  //start는 false, 나머지는 0을 기본값으로 가진다.

}
