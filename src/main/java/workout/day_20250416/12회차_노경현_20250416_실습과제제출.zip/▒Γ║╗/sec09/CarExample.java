package workout.day_20250416.기본.sec09;

public class CarExample {

  public static void main(String[] args) {
    Car c = new Car("마을버스");
    c.setSpeed(10);
    c.run();
  }

}
