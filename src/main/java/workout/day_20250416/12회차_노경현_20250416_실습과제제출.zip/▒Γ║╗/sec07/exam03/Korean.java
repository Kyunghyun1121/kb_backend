package workout.day_20250416.기본.sec07.exam03;

public class Korean {
  String nation = "대한민국";
  String name;
  String ssn;
  public Korean() {
    name = "";
    ssn = "";
  }

  public Korean(String name, String ssn) {
    this.name = name;
    this.ssn = ssn;
  }
}
