package workout.day_20250416.기본.sec08.exam03;

public class CarExample {

  public static void main(String[] args) {
    Car car = new Car();
    car.setGas(5);
    car.isLeftGas();
    car.run();
  }

}
