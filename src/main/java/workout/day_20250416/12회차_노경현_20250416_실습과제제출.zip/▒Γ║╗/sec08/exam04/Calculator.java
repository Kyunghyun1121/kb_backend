package workout.day_20250416.기본.sec08.exam04;

public class Calculator {
  public double areaRectangle(double width, double height){
    return width * height;
  }
  public double areaRectangle(double width){
    return width * width;
  }
}
