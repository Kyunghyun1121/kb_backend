package workout.day_20250430.기본.sec06.exam02;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Message {
  public String command;
  public String to;
}
